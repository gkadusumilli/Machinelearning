## To run the app:
 - Just clone the repo
 - Go to StreamlitApp
 - $ streamlit run app.py
